import {
  Text,
  View,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { useState } from 'react';




const Create = ({ navigation }) => {
  const [nome, setNome] = useState('');
  const [continente, setContinente] = useState('');
  const [populacao, setPopulacao]= useState('');
  const [idioma, setIdioma]=useState('');

  const [nome_cidade, setNome_Cidade]=useState('');
  const [populaco_didade, setPopulacao_Cidade]=useState('');
  const [id_pais, setId_Pais]=useState('');

  return (

 
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="nome"
        placeholderTextColor="#C0C0C0"
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={styles.input}
        placeholder="continente"
        placeholderTextColor="#C0C0C0"
        value={continente}
        onChangeText={setContinente}
      />
      <TextInput
        style={styles.input}
        placeholder="populacao"
        placeholderTextColor="#C0C0C0"
        value={populacao}
        onChangeText={setPopulacao}
      />
        <TextInput
        style={styles.input}
        placeholder="idioma"
        placeholderTextColor="#C0C0C0"
        value={idioma}
        onChangeText={setIdioma}
      />
   
      <TouchableOpacity 
        onPress={() => navigation.navigate('Create')}
        style={styles.button}>
        <Text style={{color:'#FFFFFF'}}>Inserir Pais</Text>
      </TouchableOpacity>
           <TextInput
        style={styles.input}
        placeholder="nome"
        placeholderTextColor="#C0C0C0"
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={styles.input}
        placeholder="continente"
        placeholderTextColor="#C0C0C0"
        value={populaco_didade}
        onChangeText={setPopulacao_Cidade}
      />
      <TextInput
        style={styles.input}
        placeholder="populacao"
        placeholderTextColor="#C0C0C0"
        value={nome}
        onChangeText={setId_Pais}
      />
      
   
      <TouchableOpacity 
        onPress={() => navigation.navigate('Create')}
        style={styles.button}>
        <Text style={{color:'#FFFFFF'}}>Inserir Cidade</Text>
      </TouchableOpacity>

   </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor:"#111F11"
  },

  button:{
    width:200, 
    borderRadius:20,
     padding:5,
    margin:10,
    alignItems:"center",
    borderColor:"white",
    borderWidth:1   
  },
  input: {
    width:200,   
    padding: 5,
    marginBottom: 10,
    backgroundColor:"white",
    borderRadius:10
  },


});
export default Create;