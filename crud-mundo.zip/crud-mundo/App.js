
import {NavigationContainer} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './screens/home.js';
import Create from './screens/create';
import Read from './screens/read';
import Update from './screens/update';
import Delete from './screens/delete';


  
const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Create" component={Create} />
        <Stack.Screen name="Read" component={Read} />
        <Stack.Screen name="Update" component={Update} />
        <Stack.Screen name="Delete" component={Delete} />
    
       
       
    
 </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
